Hello there!

This exercise involves the following main steps:

Step 1:
    Creating a new nodejs application.
    use Basic MTA from Basic Template, then do 
        npm init  
        npm i
    make new file server.js

Step 2:
    Binding a destination service on to the above application.
    DO:
        ctrl + shift + P    >   CF: Bind a service to a locally run application     >   Bind your Destination Service.   

Step 3:  
    Use @sap/xsenv
    Access the destination service from application by passing access token.

Step 4:  
    once we have access to destination service, lets look for right destination and consume it on our application.

Step 5:
    Change your mta .yaml file by adding a module for nodejs application and a resource that is destination service instance.
Step 6:
    Buils your mta.
    Deploy your mtar. 