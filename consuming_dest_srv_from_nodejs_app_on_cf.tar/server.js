"use strict";
const express = require('express');
const cfenv = require("cfenv");
const xsenv = require("@sap/xsenv");
const axios = require('axios')

var app = express();

app.get('', function(req, res){
    var data=[{"uri":"/RoleCollection"},{"uri":"/Applications"},{"uri":"/RoleCollection/Pages"},{"uri":"/Role"}]
    res.send(data);

}),

app.use('/RoleCollection', (req, res, next) => {
    xsenv.loadEnv();
    const destination = xsenv.getServices({ destination: { tag: 'destination' } }).destination;
    const credentials = {
        url: destination.url,
        uri: destination.uri,
        clientid: destination.clientid,
        clientsecret: destination.clientsecret,
        url: destination.url
    };
    var token = `${credentials.clientid}:${credentials.clientsecret}`;
    var encodedToken = Buffer.from(token).toString('base64');
    var config = {
        method: 'get',
        url: credentials.url + '/oauth/token?grant_type=client_credentials',
        headers: { 'Authorization': 'Basic ' + encodedToken }
    }
    axios(config)       //to get access token for destination service
        .then(function (response) {
            var auth_data = response.data
            const session_url1 = destination.uri + '/destination-configuration/v1/destinations/dest_dummyUI';
            var config1 = {
                method: 'get',
                url: session_url1,
                headers: {
                    'Authorization': auth_data.token_type + ' ' + auth_data.access_token
                }
            }
            axios(config1)      //to access particular destination information(data) in subaccount level
                .then(function (response) {
                    const session_url2 = response.data.destinationConfiguration.URL + '/sap/rest/authorization/v2/rolecollections';
                    var config2 = {
                        method: 'get',
                        url: session_url2,
                        headers: {
                            'Authorization': response.data.authTokens[0].type + ' ' + response.data.authTokens[0].value
                        }
                    }
                    axios(config2)
                    .then(function (response) {
                        res.send(response.data)
                    })
                })
                .catch(function (error) {
                    console.log(error);
                })
        })
        .catch(function (error) {
            console.log(error);
        })

    // res.json(["Tony","Lisa","Michael","Ginger","Food"]);
});

app.use('/Applications', (req, res, next) => {
    xsenv.loadEnv();
    const destination = xsenv.getServices({ destination: { tag: 'destination' } }).destination;
    const credentials = {
        url: destination.url,
        uri: destination.uri,
        clientid: destination.clientid,
        clientsecret: destination.clientsecret,
        url: destination.url
    };
    var token = `${credentials.clientid}:${credentials.clientsecret}`;
    var encodedToken = Buffer.from(token).toString('base64');
    var config = {
        method: 'get',
        url: credentials.url + '/oauth/token?grant_type=client_credentials',
        headers: { 'Authorization': 'Basic ' + encodedToken }
    }
    axios(config)       //to get access token for destination service
        .then(function (response) {
            var auth_data = response.data
            const session_url1 = destination.uri + '/destination-configuration/v1/destinations/dest_dummyUI';
            var config1 = {
                method: 'get',
                url: session_url1,
                headers: {
                    'Authorization': auth_data.token_type + ' ' + auth_data.access_token
                }
            }
            axios(config1)      //to access particular destination information(data) in subaccount level
                .then(function (response) {
                    const session_url2 = response.data.destinationConfiguration.URL + '/sap/rest/authorization/v2/apps';
                    var config2 = {
                        method: 'get',
                        url: session_url2,
                        headers: {
                            'Authorization': response.data.authTokens[0].type + ' ' + response.data.authTokens[0].value
                        }
                    }
                    axios(config2)
                    .then(function (response) {
                        res.send(response.data)
                    })
                })
                .catch(function (error) {
                    console.log(error);
                })
        })
        .catch(function (error) {
            console.log(error);
        })
});

app.use('/RoleCollection/Pages', (req, res, next) => {
    xsenv.loadEnv();
    const destination = xsenv.getServices({ destination: { tag: 'destination' } }).destination;
    const credentials = {
        url: destination.url,
        uri: destination.uri,
        clientid: destination.clientid,
        clientsecret: destination.clientsecret,
        url: destination.url
    };
    var token = `${credentials.clientid}:${credentials.clientsecret}`;
    var encodedToken = Buffer.from(token).toString('base64');
    var config = {
        method: 'get',
        url: credentials.url + '/oauth/token?grant_type=client_credentials',
        headers: { 'Authorization': 'Basic ' + encodedToken }
    }
    axios(config)       //to get access token for destination service
        .then(function (response) {
            var auth_data = response.data
            const session_url1 = destination.uri + '/destination-configuration/v1/destinations/dest_dummyUI';
            var config1 = {
                method: 'get',
                url: session_url1,
                headers: {
                    'Authorization': auth_data.token_type + ' ' + auth_data.access_token
                }
            }
            axios(config1)      //to access particular destination information(data) in subaccount level
                .then(function (response) {
                    const session_url2 = response.data.destinationConfiguration.URL + '/sap/rest/authorization/v2/rolecollections/Pages';
                    var config2 = {
                        method: 'get',
                        url: session_url2,
                        headers: {
                            'Authorization': response.data.authTokens[0].type + ' ' + response.data.authTokens[0].value
                        }
                    }
                    axios(config2)
                    .then(function (response) {
                        res.send(response.data)
                    })
                })
                .catch(function (error) {
                    console.log(error);
                })
        })
        .catch(function (error) {
            console.log(error);
        })

    // res.json(["Tony","Lisa","Michael","Ginger","Food"]);
});

app.use('/Role', (req, res, next) => {
    xsenv.loadEnv();
    const destination = xsenv.getServices({ destination: { tag: 'destination' } }).destination;
    const credentials = {
        url: destination.url,
        uri: destination.uri,
        clientid: destination.clientid,
        clientsecret: destination.clientsecret,
        url: destination.url
    };
    var token = `${credentials.clientid}:${credentials.clientsecret}`;
    var encodedToken = Buffer.from(token).toString('base64');
    var config = {
        method: 'get',
        url: credentials.url + '/oauth/token?grant_type=client_credentials',
        headers: { 'Authorization': 'Basic ' + encodedToken }
    }
    axios(config)       //to get access token for destination service
        .then(function (response) {
            var auth_data = response.data
            const session_url1 = destination.uri + '/destination-configuration/v1/destinations/dest_dummyUI';
            var config1 = {
                method: 'get',
                url: session_url1,
                headers: {
                    'Authorization': auth_data.token_type + ' ' + auth_data.access_token
                }
            }
            axios(config1)      //to access particular destination information(data) in subaccount level
                .then(function (response) {
                    const session_url2 = response.data.destinationConfiguration.URL + '/sap/rest/authorization/v2/roles';
                    var config2 = {
                        method: 'get',
                        url: session_url2,
                        headers: {
                            'Authorization': response.data.authTokens[0].type + ' ' + response.data.authTokens[0].value
                        }
                    }
                    axios(config2)
                    .then(function (response) {
                        res.send(response.data)
                    })
                })
                .catch(function (error) {
                    console.log(error);
                })
        })
        .catch(function (error) {
            console.log(error);
        })

    // res.json(["Tony","Lisa","Michael","Ginger","Food"]);
});


var appEnv = cfenv.getAppEnv();
app.listen(appEnv.port, function () {
    console.log("server starting on " + appEnv.url);
})
