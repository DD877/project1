sap.ui.define(["sap/ui/core/mvc/Controller",
'sap/ui/model/Filter',
'sap/ui/model/FilterOperator',],
/**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, Filter, FilterOperator) {
    "use strict";

    return Controller.extend("holidaymaintainer.controller.main", {
        onInit: function () {
            this.oTable = this.getView().byId("tableHoliday");
            this.oFilterBar = this.getView().byId("filterbar1");
        },
        onSearch: function () {
            var sSelectedKey = this.byId("holidaySearch").getValue(); 
            var aTableFilters = new Filter({path: 'location', operator: FilterOperator.Contains, value1: sSelectedKey});
            this.oTable.getBinding("items").filter(aTableFilters);
            this.oTable.setShowOverlay(false);
        }
    });
});
