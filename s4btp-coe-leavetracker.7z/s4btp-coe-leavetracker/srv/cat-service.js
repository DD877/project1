// const http = require('http');

// module.exports = srv => {
//     const { Employees } = cds.entities('my.bookshop');
//     srv.after('READ', 'Employee', (req) => {
//         console.log(req)
//     });
// }