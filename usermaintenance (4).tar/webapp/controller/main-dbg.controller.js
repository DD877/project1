sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/ui/Device",
    "sap/base/Log",
    "sap/ui/model/json/JSONModel",
    'sap/m/Token',
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/export/library",
    "sap/ui/export/Spreadsheet",
    "sap/ui/model/Sorter"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, MessageToast, Device, Log, JSONModel, Token, Filter, FilterOperator, exportLibrary, Spreadsheet, Sorter) {
        "use strict";

        return Controller.extend("ppg.usermaintenance.usermaintenance.controller.main", {
            onInit: function () {
                var that = this,
                    dataModel = this.getOwnerComponent().getModel("TableData");
                this.descendingSort  = false;
                this.getView().setModel(dataModel, "Roles");

                this.getSplitAppObj().setHomeIcon({
                    'phone': 'phone-icon.png',
                    'tablet': 'tablet-icon.png',
                    'icon': 'desktop.ico'
                });
                Device.orientation.attachHandler(this.onOrientationChange, this);

                //-----------------------------------------------------------------------------------------------------------------------------                
                // var requestUrl = "https://b6f3e045trial.authentication.eu10.hana.ondemand.com" + "/oauth/token?grant_type=client_credentials",
                //     uName = "sb-na-4373e452-5505-42d7-8977-bf396a65b7d6!a128504",
                //     passwrd = "e38c3eed-b60f-4152-95c3-593f0f6821ab$dya8kcqHQER9oAzWgA9WfHq5kHrZt3vhmHcZchjWQPg=";
                //GETTING ACCESS TOKEN FOR FROM Authorization and Trust Management Service(xsuaa) --instance name "uaa"--
                // $.ajax({
                //     type: "POST",
                //     url: requestUrl,
                //     beforeSend: function (xhr) {
                //         xhr.setRequestHeader('Authorization', "Basic " + btoa(uName + ":" + passwrd));
                //     },
                //     async: true,
                //     success: function (data) {
                //         console.log(data);
                //         var acs_token = data.access_token,
                //             tkn_type = data.token_type,
                //             // reqUrl = "https://cors-anywhere.herokuapp.com/"+"https://api.authentication.eu10.hana.ondemand.com" + "/sap/rest/authorization/v2/roles";
                //             // reqUrl = "https://api.authentication.eu10.hana.ondemand.com/sap/rest/authorization/v2/roles";
                //             reqUrl = "/apiuaa/sap/rest/authorization/v2/roles"
                //         $.ajax({
                //             type: "GET",
                //             url: reqUrl,
                //             crossDomain: false,
                //             beforeSend: function (xhr) {
                //                 xhr.setRequestHeader("Authorization", tkn_type + " " + acs_token);
                //                 // xhr.setRequestHeader("Authorization", false); 
                //                 xhr.setRequestHeader("Accept", "application/json");
                //                 xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                //                 xhr.setRequestHeader("cache-control", "no-cache");
                //                 xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
                //             },
                //             async: true,
                //             success: function (data) {
                //                 console.log(data);
                //             }
                //         })
                //     }
                // })
                // ------------------------------------------------------------------------------------------------------

                //Create JSON Model with URL
                // var oModel = new JSONModel();
                //API URL
                // var url = "https://sandbox.api.sap.com/SCPAuthtrustmgmt/platform/sap/rest/authorization/v2/roles";

                //API Key for API Sandbox
                // var sHeaders = {
                //         "APIKey":"tEjA1kPiQ4plHrSQKvUYsBXxmoSsmLIA",
                //         "DataServiceVersion":"2.0",
                //         "Accept":"application/json"
                //     };

                //sending request
                //API endpoint for API sandbox 
                // oModel.loadData(url, null, true, "GET", null, false, sHeaders);

                //You can assign the created data model to a View and UI5 controls can be bound to it. Please refer documentation available at the below link for more information.
                //https://sapui5.hana.ondemand.com/#docs/guide/96804e3315ff440aa0a50fd290805116.html#loio96804e3315ff440aa0a50fd290805116

                //The below code snippet for printing on the console is for testing/demonstration purpose only. This must not be done in real UI5 applications.
                // oModel.attachRequestCompleted(function(oEvent){
                //     var oData = oEvent.getSource().oData;
                //     console.log(oData);
                // });

                //----------------------------------------
                // var data = null;
                // var xhr = new XMLHttpRequest();
                // xhr.withCredentials = false;

                // xhr.addEventListener("readystatechange", function () {
                //     if (this.readyState === this.DONE) {
                //         console.log(this.responseText);
                //     }
                // });

                // //setting request method
                // //API endpoint for API sandbox 
                // xhr.open("GET", "https://sandbox.api.sap.com/SCPAuthtrustmgmt/platform/sap/rest/authorization/v2/roles");

                // //adding request headers
                // //API Key for API Sandbox
                // xhr.setRequestHeader("APIKey", "tEjA1kPiQ4plHrSQKvUYsBXxmoSsmLIA");
                // xhr.setRequestHeader("DataServiceVersion", "2.0");
                // xhr.setRequestHeader("Accept", "application/json");

                // //sending request
                // xhr.send(data);
                // console.log(data);

                //----------------------------------------

                // var myHeaders = new Headers();
                // // I hid my actual API key with the x's
                // myHeaders.append("APIKey", "tEjA1kPiQ4plHrSQKvUYsBXxmoSsmLIA");
                // myHeaders.append("DataServiceVersion","2.0");
                // myHeaders.append("Accept", "application/json");

                // var requestOptions = {
                //     method: 'GET',
                //     headers: myHeaders,
                //     redirect: 'follow'
                // };
                // var url = "https://sandbox.api.sap.com/SCPAuthtrustmgmt/platform/sap/rest/authorization/v2/roles";

                // var model = new JSONModel();
                // this.getView().setModel(model, "bball")
                // //set bball model
                // fetch(url, requestOptions)
                // .then(response => response.text())
                // .then(result =>  model.setData(result))
                // .catch(error => console.log('error', error));

                //---------------------------------------------------------------------
                // $.ajax({
                //     headers: {
                //         Authorization: header,
                //         "Accept": "application/json",
                //         "Content-Type": "application/json"
                //     },
                //     type: "GET",
                //     url: "https://sandbox.api.sap.com/SCPAuthtrustmgmt/platform/sap/rest/authorization/v2/roles",
                //     beforeSend: function(xhr) {
                //         xhr.setRequestHeader("APIKey", "tEjA1kPiQ4plHrSQKvUYsBXxmoSsmLIA");
                //     },
                //     crossDomain: true,
                //     dataType: "json",
                //     success: function(result) {
                //         console.log(JSON.stringify(result));
                //     },
                //     error: function(response) {}
                // });
                //------------------------------------------------------------------------------
                //---------------------------------------------
                // $.ajax({
                //     headers: {
                //         "APIKey":"tEjA1kPiQ4plHrSQKvUYsBXxmoSsmLIA",
                //         "DataServiceVersion":"2.0",
                //         "Accept":"application/json",
                //         "Access-Control-Allow-Origin": "*"
                //     },
                //     url: "https://sandbox.api.sap.com/SCPAuthtrustmgmt/platform/sap/rest/authorization/v2/roles",
                //     type: "GET",
                //     crossDomain: true,
                //     success: function(obj) { 
                //         console.log(obj);
                //     },
                //     error: function(response) {}
                //  });
            },

            onExit: function () {
                Device.orientation.detachHandler(this.onOrientationChange, this);
            },

            onOrientationChange: function (mParams) {
                var sMsg = "Orientation now is: " + (mParams.landscape ? "Landscape" : "Portrait");
                MessageToast.show(sMsg, { duration: 5000 });
            },

            onPressNavToDetail: function () {
                this.getSplitAppObj().to(this.createId("detailDetail"));
            },

            onPressDetailBack: function () {
                this.getSplitAppObj().backDetail();
            },

            onPressMasterBack: function () {
                this.getSplitAppObj().backMaster();
            },

            onPressGoToMaster: function () {
                this.getSplitAppObj().toMaster(this.createId("master2"));
            },

            onPressGoToUser: function () {
                this.getSplitAppObj().to(this.createId("detail"));
            },
            onPressGoToRoleCollection: function () {
                this.getSplitAppObj().to(this.createId("detailDetail"));
            },
            onPressGoToRole: function () {
                this.getSplitAppObj().to(this.createId("detail2"));
            },

            onListItemPress: function (oEvent) {
                var sToPageId = oEvent.getParameter("listItem").getCustomData()[0].getValue();

                this.getSplitAppObj().toDetail(this.createId(sToPageId));
            },

            onPressModeBtn: function (oEvent) {
                var sSplitAppMode = oEvent.getSource().getSelectedButton().getCustomData()[0].getValue();

                this.getSplitAppObj().setMode(sSplitAppMode);
                MessageToast.show("Split Container mode is changed to: " + sSplitAppMode, { duration: 5000 });
            },


            getSplitAppObj: function () {
                var result = this.byId("SplitAppDemo");
                if (!result) {
                    Log.info("SplitApp object can't be found");
                }
                return result;
            },
            copyRoleCollection: function (event) {
            },
            onOpenDialogUser: function (event) {
                if (!this.pDialog) {
                    this.pDialog = this.loadFragment({
                        name: "ppg.usermaintenance.usermaintenance.fragment.userdialog"
                    });
                }
                this.pDialog.then(function (oDialog) {
                    oDialog.open();
                });
            },
            onCloseDialogUser: function () {
                // note: We don't need to chain to the pDialog promise, since this event-handler
                // is only called from within the loaded dialog itself.
                this.byId("userDialog").close();
                var userName = this.byId("ip_username").setValue(""),
                    identityProvider = this.byId("ip_idProvider").setValue(""),
                    emailAddress = this.byId("ip_email").setValue("");
            },
            handleSaveBtnPress: function (oevent) {
                var that = this;
                var userName = this.byId("ip_username").getValue(),
                    identityProvider = this.byId("ip_idProvider").getValue(),
                    emailAddress = this.byId("ip_email").getValue(),
                    date = Date();
                var newUserRecord = {
                    "username": userName,
                    "identityProvider": identityProvider,
                    "lastName": "",
                    "firstName": "",
                    "email": emailAddress,
                    "lastUpdated": date,
                    "lastLogon": ""
                };

                var otableData = oevent.getSource().getModel("Roles").getData();
                otableData.users.push(newUserRecord);
                that.getView().getModel("Roles").setData(otableData);
                this.byId("userDialog").close();
                var userName = this.byId("ip_username").setValue(""),
                    identityProvider = this.byId("ip_idProvider").setValue(""),
                    emailAddress = this.byId("ip_email").setValue("");
            },
            onUserDelete: function (oEvent) {
                var that = this;
                var data = oEvent.getSource();
                var deleteRowData = oEvent.getSource().getParent().getCells().map((obj) => { return (obj.mProperties.text) });
                var deleteUserRecord = {
                    "username": deleteRowData[0],
                    "identityProvider": deleteRowData[1],
                    "lastName": deleteRowData[2],
                    "firstName": deleteRowData[3],
                    "email": deleteRowData[4],
                    "lastUpdated": deleteRowData[5],
                    "lastLogon": deleteRowData[6]
                };
                var indexSlice;
                var otableData = oEvent.getSource().getModel("Roles").getData();
                otableData.users.forEach((obj, index) => {
                    if (obj.username === deleteUserRecord.username) {
                        if (!indexSlice) {
                            indexSlice = index;
                        }
                    }
                });
                otableData.users.splice(indexSlice, 1);
                that.getView().getModel("Roles").setData(otableData);
            },
            //search user
            onSearch: function (oEvent) {
                var aFilter = [];
                var sQuery = oEvent.getParameter("query");
                if (sQuery) {
                    aFilter.push(new Filter("username", FilterOperator.Contains, sQuery));
                }
                var oTable = this.getView().byId("idUserTable");
                var oBinding = oTable.getBinding("items");
                oBinding.filter(aFilter, "Application");
            },
            //search rc
            onSearchrc: function (oEvent) {
                var aFilter = [];
                var sQuery = oEvent.getParameter("query");
                if (sQuery) {
                    aFilter.push(new Filter("name", FilterOperator.Contains, sQuery));
                }
                var oTable = this.getView().byId("idRoleCollectionsTable");
                var oBinding = oTable.getBinding("items");
                oBinding.filter(aFilter, "Application");
            },
            //search role
            onSearchr: function (oEvent) {
                var aFilter = [];
                var sQuery = oEvent.getParameter("query");
                if (sQuery) {
                    aFilter.push(new Filter("appName", FilterOperator.Contains, sQuery));
                }
                var oTable = this.getView().byId("idRolesTable");
                var oBinding = oTable.getBinding("items");
                oBinding.filter(aFilter, "Application");
            },
            //EXPORT User Data
            createColumnConfig: function () {
                var aCols = [];

                aCols.push({
                    label: 'user name',
                    type: exportLibrary.EdmType.String,
                    property: 'username',
                    scale: 0
                });
                aCols.push({
                    label: 'identity Provider',
                    type: exportLibrary.EdmType.String,
                    property: 'identityProvider',
                    scale: 0
                });
                aCols.push({
                    label: 'last Name',
                    type: exportLibrary.EdmType.String,
                    property: 'lastName',
                    scale: 0
                });
                aCols.push({
                    label: 'first Name',
                    type: exportLibrary.EdmType.String,
                    property: 'firstName',
                    scale: 0
                });
                aCols.push({
                    label: 'Email',
                    type: exportLibrary.EdmType.String,
                    property: 'email',
                    scale: 0
                });
                aCols.push({
                    label: 'last Updated',
                    type: exportLibrary.EdmType.String,
                    property: 'lastUpdated',
                    scale: 0
                });
                aCols.push({
                    label: 'last Logon',
                    type: exportLibrary.EdmType.String,
                    property: 'lastLogon',
                    scale: 0
                });

                return aCols;
            },
            onExport: function () {
                var aCols, oRowBinding, oSettings, oSheet, oTable;
                if (!this._oTable) {
                    this._oTable = this.byId('idUserTable');
                }

                oTable = this._oTable;
                oRowBinding = oTable.getBinding('items');
                aCols = this.createColumnConfig();

                oSettings = {
                    workbook: {
                        columns: aCols,
                        hierarchyLevel: 'Level'
                    },
                    dataSource: oRowBinding,
                    fileName: 'BTP_CF_Users.xlsx',
                    worker: false // We need to disable worker because we are using a MockServer as OData Service
                };

                oSheet = new Spreadsheet(oSettings);
                oSheet.build().finally(function () {
                    oSheet.destroy();
                });
            },
            //EXPORT Role Collections Data
            createColumnConfigrc: function () {
                var aCols = [];

                aCols.push({
                    label: 'name',
                    type: exportLibrary.EdmType.String,
                    property: 'name',
                    scale: 0
                });
                aCols.push({
                    label: 'description',
                    type: exportLibrary.EdmType.String,
                    property: 'description',
                    scale: 0
                });

                return aCols;
            },
            onExportrc: function () {
                var aCols, oRowBinding, oSettings, oSheet, oTable;
                if (!this._oTable) {
                    this._oTable = this.byId('idRoleCollectionsTable');
                }

                oTable = this._oTable;
                oRowBinding = oTable.getBinding('items');
                aCols = this.createColumnConfigrc();

                oSettings = {
                    workbook: {
                        columns: aCols,
                        hierarchyLevel: 'Level'
                    },
                    dataSource: oRowBinding,
                    fileName: 'BTP_CF_Role_Collection.xlsx',
                    worker: false // We need to disable worker because we are using a MockServer as OData Service
                };

                oSheet = new Spreadsheet(oSettings);
                oSheet.build().finally(function () {
                    oSheet.destroy();
                });
            },
            //EXPORT Role Data
            createColumnConfigr: function () {
                var aCols = [];

                aCols.push({
                    label: 'appName',
                    type: exportLibrary.EdmType.String,
                    property: 'appName',
                    scale: 0
                });
                aCols.push({
                    label: 'appDescription',
                    type: exportLibrary.EdmType.String,
                    property: 'appDescription',
                    scale: 0
                });
                aCols.push({
                    label: 'roleTemplateName',
                    type: exportLibrary.EdmType.String,
                    property: 'roleTemplateName',
                    scale: 0
                });
                aCols.push({
                    label: 'name',
                    type: exportLibrary.EdmType.String,
                    property: 'name',
                    scale: 0
                });
                aCols.push({
                    label: 'description',
                    type: exportLibrary.EdmType.String,
                    property: 'description',
                    scale: 0
                });

                return aCols;
            },
            onExport: function () {
                var aCols, oRowBinding, oSettings, oSheet, oTable;
                if (!this._oTable) {
                    this._oTable = this.byId('idRolesTable');
                }

                oTable = this._oTable;
                oRowBinding = oTable.getBinding('items');
                aCols = this.createColumnConfigr();

                oSettings = {
                    workbook: {
                        columns: aCols,
                        hierarchyLevel: 'Level'
                    },
                    dataSource: oRowBinding,
                    fileName: 'BTP_CF_Roles.xlsx',
                    worker: false // We need to disable worker because we are using a MockServer as OData Service
                };

                oSheet = new Spreadsheet(oSettings);
                oSheet.build().finally(function () {
                    oSheet.destroy();
                });
            },
            onOpenDialogRoleCollection: function (event) {
                if (!this.prcDialog) {
                    this.prcDialog = this.loadFragment({
                        name: "ppg.usermaintenance.usermaintenance.fragment.roleCollectiondialog"
                    });
                }
                this.prcDialog.then(function (oDialog) {
                    oDialog.open();
                });
            },
            onCloseDialogRoleCollection: function () {
                // note: We don't need to chain to the pDialog promise, since this event-handler
                // is only called from within the loaded dialog itself.
                this.byId("roleCollectiondialog").close();
                var rcName = this.byId("ip_rcname").setValue(""),
                    desc = this.byId("ip_desc").setValue();
            },

            handleSaveBtnPressRC: function (oevent) {
                var that = this;
                var rcName = this.byId("ip_rcname").getValue(),
                    desc = this.byId("ip_desc").getValue(),
                    newRC_Record = {
                        "name": rcName,
                        "description": desc,
                        "roleReferences": [
                            {
                                "roleTemplateAppId": "",
                                "roleTemplateName": "",
                                "name": "",
                                "description": ""
                            }
                        ],
                        "isReadOnly": true
                    };

                var otableData = oevent.getSource().getModel("Roles").getData();
                otableData.roleCollection.push(newRC_Record);
                that.getView().getModel("Roles").setData(otableData);
                this.byId("roleCollectiondialog").close();
                var rcName = this.byId("ip_rcname").setValue(""),
                    desc = this.byId("ip_desc").setValue();

            },
            onRC_Delete: function (oEvent) {
                var that = this,
                    data = oEvent.getSource(),
                    deleteRowData = oEvent.getSource().getParent().getParent().getCells().map((obj) => { return (obj.mProperties.text) }),
                    deleteUserRecord = {
                        "name": deleteRowData[0],
                        "description": deleteRowData[1],
                        "roleReferences": [
                            {
                                "roleTemplateAppId": "",
                                "roleTemplateName": "",
                                "name": "",
                                "description": ""
                            }
                        ],
                        "isReadOnly": true
                    };
                var indexSlice;
                var otableData = oEvent.getSource().getModel("Roles").getData();
                otableData.roleCollection.forEach((obj, index) => {
                    if (obj.name === deleteUserRecord.name) {
                        if (!indexSlice) {
                            indexSlice = index;
                            return;
                        }
                    }
                });
                otableData.roleCollection.splice(indexSlice, 1);
                that.getView().getModel("Roles").setData(otableData);
            },
            //sort user table
            onSort: function () {
                this.descendingSort = !this.descendingSort;
                var oTable = this.getView().byId("idUserTable");
                var oBinding = oTable.getBinding("items");
                var oSorter = new Sorter("username", this.descendingSort);
                oBinding.sort(oSorter);
            },
            //sort idRoleCollectionsTable table
            onSortrc: function () {
                this.descendingSort = !this.descendingSort;
                var oTable = this.getView().byId("idRoleCollectionsTable");
                var oBinding = oTable.getBinding("items");
                var oSorter = new Sorter("name", this.descendingSort);
                oBinding.sort(oSorter);
            },
            //sort idRolesTable table
            onSortr: function () {
                this.descendingSort = !this.descendingSort;
                var oTable = this.getView().byId("idRolesTable");
                var oBinding = oTable.getBinding("items");
                var oSorter = new Sorter("appName", this.descendingSort);
                oBinding.sort(oSorter);
            }
        });
    });
