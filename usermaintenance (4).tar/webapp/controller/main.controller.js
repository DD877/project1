sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/ui/Device",
    "sap/base/Log",
    "sap/ui/model/json/JSONModel",
    "sap/m/Token",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/export/library",
    "sap/ui/export/Spreadsheet",
    "sap/ui/model/Sorter",
    "../model/formatter"
], function (e, t, i, a, o, n, r, s, l, p, c, formatter) {
    "use strict";
    return e.extend("ppg.usermaintenance.usermaintenance.controller.main", {
        formatter: formatter,
        onInit: function () {
            var e = this,
                t = this.getOwnerComponent().getModel("TableData");
            this.descendingSort = false;
            this.getView().setModel(t, "Roles");
            this.getSplitAppObj().setHomeIcon({phone: "phone-icon.png", tablet: "tablet-icon.png", icon: "desktop.ico"});
            i.orientation.attachHandler(this.onOrientationChange, this)
        },
        onExit: function () {
            i.orientation.detachHandler(this.onOrientationChange, this)
        },
        onOrientationChange: function (e) {
            var i = "Orientation now is: " + (
            e.landscape ? "Landscape" : "Portrait"
        );
            t.show(i, {duration: 5e3})
        },
        onPressNavToDetail: function () {
            this.getSplitAppObj().to(this.createId("detailDetail"))
        },
        onPressDetailBack: function () {
            this.getSplitAppObj().backDetail()
        },
        onPressMasterBack: function () {
            this.getSplitAppObj().backMaster()
        },
        onPressGoToMaster: function () {
            this.getSplitAppObj().toMaster(this.createId("master2"))
        },
        onPressGoToUser: function () {
            this.getSplitAppObj().to(this.createId("detail"))
        },
        onPressGoToRoleCollection: function () {
            this.getSplitAppObj().to(this.createId("detailDetail"))
        },
        onPressGoToRole: function () {
            this.getSplitAppObj().to(this.createId("detail2"))
        },
        onListItemPress: function (e) {
            // var t = e.getParameter("listItem").getCustomData()[0].getValue();
            // this.getSplitAppObj().toDetail(this.createId(t))
        },
        onPressModeBtn: function (e) {
            var i = e.getSource().getSelectedButton().getCustomData()[0].getValue();
            this.getSplitAppObj().setMode(i);
            t.show("Split Container mode is changed to: " + i, {duration: 5e3})
        },
        getSplitAppObj: function () {
            var e = this.byId("SplitAppDemo");
            if (! e) {
                a.info("SplitApp object can't be found")
            }
            return e
        },
        copyRoleCollection: function (e) {},
        onOpenDialogUser: function (e) {
            if (!this.pDialog) {
                this.pDialog = this.loadFragment({name: "ppg.usermaintenance.usermaintenance.fragment.userdialog"})
            }
            this.pDialog.then(function (e) {
                e.open()
            })
        },
        onCloseDialogUser: function () {
            this.byId("userDialog").close();
            var e = this.byId("ip_username").setValue(""),
                t = this.byId("ip_idProvider").setValue(""),
                i = this.byId("ip_email").setValue("")
        },
        handleSaveBtnPress: function (e) {
            var t = this;
            var i = this.byId("ip_username").getValue(),
                a = this.byId("ip_idProvider").getValue(),
                o = this.byId("ip_email").getValue(),
                n = Date();
            var r = {
                username: i,
                identityProvider: a,
                lastName: "",
                firstName: "",
                email: o,
                lastUpdated: n,
                lastLogon: ""
            };
            var s = e.getSource().getModel("Roles").getData();
            s.users.push(r);
            t.getView().getModel("Roles").setData(s);
            this.byId("userDialog").close();
            var i = this.byId("ip_username").setValue(""),
                a = this.byId("ip_idProvider").setValue(""),
                o = this.byId("ip_email").setValue("")
        },
        onUserDelete: function (e) {
            var t = this;
            var i = e.getSource();
            var a = e.getSource().getParent().getCells().map(e => e.mProperties.text);
            var o = {
                username: a[0],
                identityProvider: a[1],
                lastName: a[2],
                firstName: a[3],
                email: a[4],
                lastUpdated: a[5],
                lastLogon: a[6]
            };
            var n;
            var r = e.getSource().getModel("Roles").getData();
            r.users.forEach((e, t) => {
                if (e.username === o.username) {
                    if (! n) {
                        n = t
                    }
                }
            });
            r.users.splice(n, 1);
            t.getView().getModel("Roles").setData(r)
        },
        onSearch: function (e) {
            var t = [];
            var i = e.getParameter("query");
            if (i) {
                t.push(new r("username", s.Contains, i))
            }
            var a = this.getView().byId("idUserTable");
            var o = a.getBinding("items");
            o.filter(t, "Application")
        },
        onSearchrc: function (e) {
            var t = [];
            var i = e.getParameter("query");
            if (i) {
                t.push(new r("name", s.Contains, i))
            }
            var a = this.getView().byId("idRoleCollectionsTable");
            var o = a.getBinding("items");
            o.filter(t, "Application")
        },
        onSearchr: function (e) {
            var t = [];
            var i = e.getParameter("query");
            if (i) {
                t.push(new r("appName", s.Contains, i))
            }
            var a = this.getView().byId("idRolesTable");
            var o = a.getBinding("items");
            o.filter(t, "Application")
        },
        createColumnConfig: function () {
            var e = [];
            e.push({label: "user name", type: l.EdmType.String, property: "username", scale: 0});
            e.push({label: "identity Provider", type: l.EdmType.String, property: "identityProvider", scale: 0});
            e.push({label: "last Name", type: l.EdmType.String, property: "lastName", scale: 0});
            e.push({label: "first Name", type: l.EdmType.String, property: "firstName", scale: 0});
            e.push({label: "Email", type: l.EdmType.String, property: "email", scale: 0});
            e.push({label: "last Updated", type: l.EdmType.String, property: "lastUpdated", scale: 0});
            e.push({label: "last Logon", type: l.EdmType.String, property: "lastLogon", scale: 0});
            return e
        },
        onExport: function () {
            var e,
                t,
                i,
                a,
                o;
            if (!this._oTable) {
                this._oTable = this.byId("idUserTable")
            }
            o = this._oTable;
            t = o.getBinding("items");
            e = this.createColumnConfig();
            i = {
                workbook: {
                    columns: e,
                    hierarchyLevel: "Level"
                },
                dataSource: t,
                fileName: "BTP_CF_Users.xlsx",
                worker: false
            };
            a = new p(i);
            a.build(). finally(function () {
                a.destroy()
            })
        },
        createColumnConfigrc: function () {
            var e = [];
            e.push({label: "name", type: l.EdmType.String, property: "name", scale: 0});
            e.push({label: "description", type: l.EdmType.String, property: "description", scale: 0});
            return e
        },
        onExportrc: function () {
            var e,
                t,
                i,
                a,
                o;
            if (!this._oTablerc) {
                this._oTablerc = this.byId("idRoleCollectionsTable")
            }
            o = this._oTablerc;
            t = o.getBinding("items");
            e = this.createColumnConfigrc();
            i = {
                workbook: {
                    columns: e,
                    hierarchyLevel: "Level"
                },
                dataSource: t,
                fileName: "BTP_CF_Role_Collection.xlsx",
                worker: false
            };
            a = new p(i);
            a.build(). finally(function () {
                a.destroy()
            })
        },
        createColumnConfigr: function () {
            var e = [];
            e.push({label: "appName", type: l.EdmType.String, property: "appName", scale: 0});
            e.push({label: "appDescription", type: l.EdmType.String, property: "appDescription", scale: 0});
            e.push({label: "roleTemplateName", type: l.EdmType.String, property: "roleTemplateName", scale: 0});
            e.push({label: "name", type: l.EdmType.String, property: "name", scale: 0});
            e.push({label: "description", type: l.EdmType.String, property: "description", scale: 0});
            return e
        },
        onExportr: function () {
            var e,
                t,
                i,
                a,
                o;
            if (!this._oTabler) {
                this._oTabler = this.byId("idRolesTable")
            }
            o = this._oTabler;
            t = o.getBinding("items");
            e = this.createColumnConfigr();
            i = {
                workbook: {
                    columns: e,
                    hierarchyLevel: "Level"
                },
                dataSource: t,
                fileName: "BTP_CF_Roles.xlsx",
                worker: false
            };
            a = new p(i);
            a.build(). finally(function () {
                a.destroy()
            })
        },
        onOpenDialogRoleCollection: function (e) {
            if (!this.prcDialog) {
                this.prcDialog = this.loadFragment({name: "ppg.usermaintenance.usermaintenance.fragment.roleCollectiondialog"})
            }
            this.prcDialog.then(function (e) {
                e.open()
            })
        },
        onCloseDialogRoleCollection: function () {
            this.byId("roleCollectiondialog").close();
            var e = this.byId("ip_rcname").setValue(""),
                t = this.byId("ip_desc").setValue()
        },
        handleSaveBtnPressRC: function (e) {
            var t = this;
            var i = this.byId("ip_rcname").getValue(),
                a = this.byId("ip_desc").getValue(),
                o = {
                    name: i,
                    description: a,
                    roleReferences: [
                        {
                            roleTemplateAppId: "",
                            roleTemplateName: "",
                            name: "",
                            description: ""
                        }
                    ],
                    isReadOnly: true
                };
            var n = e.getSource().getModel("Roles").getData();
            n.roleCollection.push(o);
            t.getView().getModel("Roles").setData(n);
            this.byId("roleCollectiondialog").close();
            var i = this.byId("ip_rcname").setValue(""),
                a = this.byId("ip_desc").setValue()
        },
        onRC_Delete: function (e) {
            var t = this,
                i = e.getSource(),
                a = e.getSource().getParent().getParent().getCells().map(e => e.mProperties.text),
                o = {
                    name: a[0],
                    description: a[1],
                    roleReferences: [
                        {
                            roleTemplateAppId: "",
                            roleTemplateName: "",
                            name: "",
                            description: ""
                        }
                    ],
                    isReadOnly: true
                };
            var n;
            var r = e.getSource().getModel("Roles").getData();
            r.roleCollection.forEach((e, t) => {
                if (e.name === o.name) {
                    if (! n) {
                        n = t;
                        return
                    }
                }
            });
            r.roleCollection.splice(n, 1);
            t.getView().getModel("Roles").setData(r)
        },
        onSort: function () {
            this.descendingSort = !this.descendingSort;
            var e = this.getView().byId("idUserTable");
            var t = e.getBinding("items");
            var i = new c("username", this.descendingSort);
            t.sort(i)
        },
        onSortrc: function () {
            this.descendingSort = !this.descendingSort;
            var e = this.getView().byId("idRoleCollectionsTable");
            var t = e.getBinding("items");
            var i = new c("name", this.descendingSort);
            t.sort(i)
        },
        onSortr: function () {
            this.descendingSort = !this.descendingSort;
            var e = this.getView().byId("idRolesTable");
            var t = e.getBinding("items");
            var i = new c("appName", this.descendingSort);
            t.sort(i)
        }
    })
});
