sap.ui.define([], function () {
    "use strict";
    return {
        fooBar: function (iValue) {
            if (this.byId('multiInput').mForwardedAggregations.tokens) {
                while (this.byId('multiInput').mForwardedAggregations.tokens.length > 0) {
                    this.byId('multiInput').mForwardedAggregations.tokens.pop();
                }
            }

            if (iValue) {
                if (iValue[0].roleTemplateName == '') {
                    this.byId('multiInput').removeAllTokens();
                    return;
                }
                for (let i = 0; i < iValue.length; i++) {
                    var defToken = new sap.m.Token({text: iValue[i].roleTemplateName});
                    this.byId('multiInput').addToken(defToken);
                }
            }

            return;
        }
    };
});
