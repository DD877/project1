/* global QUnit */

sap.ui.require(["ppg/usermaintenance/usermaintenance/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
