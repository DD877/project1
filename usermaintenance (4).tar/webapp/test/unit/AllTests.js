sap.ui.define([
	"ppgusermaintenance/usermaintenance/test/unit/controller/main.controller"
], function () {
	"use strict";
});
